#include "Parameter.h"

Parameter::Parameter(const uint32_t parameter) noexcept
    : parameter(parameter) {}
