#pragma once

#define MAX_SETTINGS_STRING	0x7F

struct stSettings
{
	// client
	char szNickName[MAX_PLAYER_NAME+1];
	char szHost[MAX_SETTINGS_STRING+1];
	int iPort;
	char szPassword[MAX_SETTINGS_STRING+1];
	
	bool szTimeStamp;
	bool szRadar;
	bool szTextBG;
	bool szChatBG;
	int iBtnStyle;
	int iHudStyle;

	bool bLabelBg;
	bool bnoFX;
	float fDrawPedDist;

	// debug
	bool bDebug;
	bool bOnline;

	// gui
	char szFont[40];
	float fFontSize;
	int iFontOutline;

	// chat config
	float fChatPosX;
	float fChatPosY;
	float fChatSizeX;
	float fChatSizeY;
	int   iChatMaxMessages;
	bool  iChatShadow;

	// health config
	float fHealthBarWidth;
	float fHealthBarHeight;

	// scoreboard size
	float fScoreBoardSizeX;
	float fScoreBoardSizeY;

	// spawnbutton config
	float fSpawnScreenPosX;
	float fSpawnScreenPosY;
	float fSpawnScreenSizeX;
	float fSpawnScreenSizeY;

	// passenger config
	bool bButtonExPassengerEnable;
	float fButtonExSize;
	float fButtonExPosX;
	float fButtonExPosY;
	
	// Voicechat config
	bool bVoiceChatEnable;
	int iVoiceChatKey;
	float fVoiceChatSize;
	float fVoiceChatPosX;
	float fVoiceChatPosY;

	// FPS config
	bool bFPSEnable;
	int iFPSLimit;
	bool bFPSOutline;
	float fFPSPosX;
	float fFPSPosY;

	int iFPS;
	bool iFPSCounter;

	//==================//

	bool iAndroidKeyboard;
	bool iCutout;

	bool BTBack;
	bool BTBord;
	bool DialogBG;
	bool BTRadius;
	bool ALT, F,H,Y,N,C;
	bool TWO,SPACE,CTRL,RBM,LBM,TAB,LMB;
	bool NUM2,NUM4,NUM6,NUM8,ENTER;

	float fButtonCameraCycleX;
	float fButtonCameraCycleY;
	float fButtonCameraCycleSize;

	int iVoiceList;

	int iOutfitGuns;
	int iRadarRect;
	int iHPArmourText;
	int iPCMoney;
	int iSkyBox;
	int iSnow;

	float fButtonEnterPassengerX;
	float fButtonEnterPassengerY;
	float fButtonEnterPassengerSize;

	float fButtonMicrophoneX;
	float fButtonMicrophoneY;
	float fButtonMicrophoneSize;

	int iNameTag;
	int i3DText;
	int iVoice;
};

class CSettings
{
public:
	CSettings();
	~CSettings();

	stSettings& Get() { return m_Settings; }

	void ToDefaults(int iCategory);

	void Save(int iIgnoreCategory = 0);

	const stSettings& GetReadOnly();
	stSettings& GetWrite();
	void LoadSettings(const char* szNickName, int iChatLines = 8);

    bool timestamp;
	bool ToggleTimeStamp();
	
private:
	struct stSettings m_Settings;
};