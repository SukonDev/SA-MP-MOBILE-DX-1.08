#include "main.h"
#include "settings.h"
#include "vendor/inih/cpp/INIReader.h"

#include "vendor/SimpleIni/SimpleIni.h"
#include "util/patch.h"

void ApplyFPSPatch(uint8_t);

CSettings::CSettings()
{
	Log("Loading settings..");

	char buff[0x7F];
	sprintf(buff, "%sSAMP/settings.ini", g_pszStorage);

	INIReader reader(buff);

	if(reader.ParseError() < 0)
	{
		Log("Error: can't load %s", buff);
		std::terminate();
		return;
	}

	// client
	size_t length = 0;
	sprintf(buff, OBFUSCATE("__android_%d%d"), rand() % 1000, rand() % 1000);
	length = reader.Get("client", "name", buff).copy(m_Settings.szNickName, MAX_PLAYER_NAME);
	m_Settings.szNickName[length] = '\0';
	length = reader.Get("client", "host", "127.0.0.1").copy(m_Settings.szHost, MAX_SETTINGS_STRING);
	m_Settings.szHost[length] = '\0';
	length = reader.Get("client", "password", "").copy(m_Settings.szPassword, MAX_SETTINGS_STRING);
	m_Settings.szPassword[length] = '\0';
	m_Settings.iPort = reader.GetInteger("client", "port", 7777);

    int fpsLimit = reader.GetInteger("client", "fps", 144);
    ApplyFPSPatch(fpsLimit);

	m_Settings.szTimeStamp = reader.GetBoolean("client", "timestamp", false);
	m_Settings.szRadar = reader.GetBoolean("client", "radar", false);
	m_Settings.szTextBG = reader.GetBoolean("client", "textbg", false);
	m_Settings.szChatBG = reader.GetBoolean("client", "chatbg", false);
	m_Settings.iBtnStyle = reader.GetInteger("client", "btn_style", 0); if(m_Settings.iBtnStyle > 15) m_Settings.iBtnStyle = 1;
	m_Settings.iHudStyle = reader.GetInteger("client", "hud_style", 0);

	m_Settings.bnoFX = reader.GetBoolean("client", "noFX", false);
	m_Settings.fDrawPedDist = reader.GetReal("client", "DrawDistPed", 60.0f);
	m_Settings.bLabelBg = reader.GetBoolean("client", "label_background", false);
	
	m_Settings.iChatShadow = reader.GetBoolean("client", "ChatShadow", false);

	m_Settings.iFPSCounter = reader.GetBoolean("gui", "fpscounter", true);

	if(m_Settings.bnoFX)
	{
		//CPatch::NOP(g_libGTASA + 0x39B36A, 2);
		CPatch::WriteMemory(g_libGTASA + 0x52DD38, "\x00\x20\x70\x47", 4); // return 0 CCoronas::RenderReflections
		CPatch::NOP(g_libGTASA + 0x39AD14, 1); // skip render clouds, sunrefl, raineffect 
	}

	// debug
	m_Settings.bDebug = reader.GetBoolean("debug", "debug", false);
	m_Settings.bOnline = reader.GetBoolean("debug", "online", false);

	// gui
	length = reader.Get("gui", "Font", "arial.ttf").copy(m_Settings.szFont, MAX_SETTINGS_STRING);
	m_Settings.szFont[length] = '\0';
	m_Settings.fFontSize = reader.GetReal("gui", "FontSize", 30.0f);
	m_Settings.iFontOutline = reader.GetInteger("gui", "FontOutline", 2);

	// chat
	m_Settings.fChatPosX = reader.GetReal("gui", "ChatPosX", 325.0f);
	m_Settings.fChatPosY = reader.GetReal("gui", "ChatPosY", 25.0f);
	m_Settings.fChatSizeX = reader.GetReal("gui", "ChatSizeX", 1150.0f);
	m_Settings.fChatSizeY = reader.GetReal("gui", "ChatSizeY", 220.0f);
	m_Settings.iChatMaxMessages = reader.GetInteger("gui", "ChatMaxMessages", 6);

	// spawnscreen
	m_Settings.fSpawnScreenPosX = reader.GetReal("gui", "SpawnScreenPosX", 660.0f);
	m_Settings.fSpawnScreenPosY = reader.GetReal("gui", "SpawnScreenPosY", 950.0f);
	m_Settings.fSpawnScreenSizeX = reader.GetReal("gui", "SpawnScreenSizeX", 600.0f);
	m_Settings.fSpawnScreenSizeY = reader.GetReal("gui", "SpawnScreenSizeY", 100.0f);

	// nametags
	m_Settings.fHealthBarWidth = reader.GetReal("gui", "HealthBarWidth", 100.0f);
	m_Settings.fHealthBarHeight = reader.GetReal("gui", "HealthBarHeight", 10.0f);

	// scoreboard
	m_Settings.fScoreBoardSizeX = reader.GetReal("gui", "ScoreBoardSizeX", 846.0f);
	m_Settings.fScoreBoardSizeY = reader.GetReal("gui", "ScoreBoardSizeY", 614.0f);

	// passenger
	m_Settings.bButtonExPassengerEnable = reader.GetBoolean("gui", "ButtonExPassengerEnable", true);
	m_Settings.fButtonExSize = reader.GetReal("gui", "ButtonExSize", 25.0f);
	m_Settings.fButtonExPosX = reader.GetReal("gui", "ButtonExPosX", 120.0f);
	m_Settings.fButtonExPosY = reader.GetReal("gui", "ButtonExPosY", 430.0f);

	// voicechat
	m_Settings.bVoiceChatEnable = reader.GetBoolean("gui", "VoiceChatEnable", true);
	m_Settings.iVoiceChatKey = reader.GetInteger("gui", "VoiceChatKey", 66);
	m_Settings.fVoiceChatSize = reader.GetReal("gui", "MicroSize", 30.0f);
	m_Settings.fVoiceChatPosX = reader.GetReal("gui", "MicroPosX", 1520.0f);
	m_Settings.fVoiceChatPosY = reader.GetReal("gui", "MicroPosY", 480.0f);

	m_Settings.iAndroidKeyboard = reader.GetBoolean("debug", "GoogleKeyboard", false);

	m_Settings.iCutout = reader.GetBoolean("gui", "cutout", false);

	m_Settings.iFPSCounter = reader.GetBoolean("gui", "fpscounter", true);
	m_Settings.BTBack = reader.GetBoolean("gui", "btbackground", true);
	m_Settings.BTBord = reader.GetBoolean("gui", "btborder", true);
	m_Settings.BTRadius = reader.GetBoolean("gui", "btradi", false);
	m_Settings.TAB = reader.GetBoolean("gui", "TAB", true);
	m_Settings.ALT = reader.GetBoolean("gui", "ALT", true);
	m_Settings.F = reader.GetBoolean("gui", "F", true);
	m_Settings.C = reader.GetBoolean("gui", "C", true);
	m_Settings.Y = reader.GetBoolean("gui", "Y", true);
	m_Settings.N = reader.GetBoolean("gui", "N", true);
	m_Settings.H = reader.GetBoolean("gui", "H", true);
	m_Settings.CTRL = reader.GetBoolean("gui", "CTRL", false);
	m_Settings.RBM = reader.GetBoolean("gui", "RBM", false);
	m_Settings.LBM = reader.GetBoolean("gui", "LBM", false);
	m_Settings.ENTER = reader.GetBoolean("gui", "ENTER", false);
	m_Settings.NUM2 = reader.GetBoolean("gui", "NUM2", false);
	m_Settings.NUM4 = reader.GetBoolean("gui", "NUM4", false);
	m_Settings.NUM6 = reader.GetBoolean("gui", "NUM6", false);
	m_Settings.TWO = reader.GetBoolean("gui", "TWO", true);
	m_Settings.NUM8 = reader.GetBoolean("gui", "NUM8", false);
	m_Settings.SPACE = reader.GetBoolean("gui", "SPACE", false);
	m_Settings.LMB = reader.GetBoolean("gui", "LMB", true);
    m_Settings.iAndroidKeyboard = reader.GetBoolean("gui", "androidkeyboard", true);
	m_Settings.DialogBG = reader.GetBoolean("gui", "DialogBG", false);
}

bool CSettings::ToggleTimeStamp()
{
	char buff[0x7F];
	sprintf(buff, "%sSAMP/settings.ini", g_pszStorage);

	CSimpleIniA ini;
	ini.SetUnicode();
	ini.LoadFile(buff);
	SI_Error rc;

    timestamp = Get().szTimeStamp;
    m_Settings.szTimeStamp = !timestamp;

	rc = ini.SetBoolValue("client", "timestamp", !timestamp);
	rc = ini.SaveFile(buff);

	return (rc >= 0);
}
