#include "main.h"
#include "extrakeyboard.h"
#include "GButton.h"
#include "scoreboard.h"
#include "dialog.h"
#include "chatwindow.h"
#include "settings.h"
#include "game/game.h"
#include "net/netgame.h"

extern CGUI *pGUI;
extern CGButton *pGButton;
extern CScoreBoard *pScoreBoard;
extern CDialogWindow *pDialogWindow;
extern CChatWindow *pChatWindow;
extern CSettings *pSettings;
extern CGame *pGame;
extern CNetGame *pNetGame;

extern char szDialogInputBuffer[512];

CExtraKeyBoard::CExtraKeyBoard() 
{
	m_bIsActive = false;
	m_bIsExtraShow = false;

	SetPosition(10.0f, 365.0f);
    SetButtonSize(80.0f, 60.0f);
}

void CExtraKeyBoard::SetPosition(float posX, float posY)
{
	m_fPosX = pGUI->ScaleX(posX);
	m_fPosY = pGUI->ScaleY(posY);
}

void CExtraKeyBoard::SetButtonSize(float sizeX, float sizeY)
{
	m_fSizeX = pGUI->ScaleX(sizeX);
	m_fSizeY = pGUI->ScaleY(sizeY);
}

void CExtraKeyBoard::Render() 
{
	if(!m_bIsActive) return;

	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed) 
	{
		ImGuiIO &io = ImGui::GetIO();
		
		ImGuiStyle* style = &ImGui::GetStyle();

		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4.5f, 4.5f)); // 6.5f, 6.5f
		ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.5f, 0.5f));
		ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.96f, 0.56f, 0.19f, 1.0f));
		ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.96f, 0.56f, 0.19f, 1.0f));
		ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.96f, 0.56f, 0.19f, 1.0f));


		style->FrameRounding = 5.0f;

		ImGui::Begin(OBFUSCATE("ButtonPanel"), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings);

		float m_fButWidth = m_fSizeX;
		float m_fButHeight = m_fSizeY;

		CTextDrawPool *pTextDrawPool = pNetGame->GetTextDrawPool();
		if(pTextDrawPool)
		{
			if(pDialogWindow->GetState() || pScoreBoard->m_bToggle || pTextDrawPool->GetState())
			{
				if(ImGui::Button(OBFUSCATE("ESC"), ImVec2(m_fButWidth, m_fButHeight)))
				{
					// close dialog, scoreboard, textdraw
					if(pScoreBoard->m_bToggle)
					{
						pScoreBoard->Toggle();
					}
					else if(pTextDrawPool->GetState())
					{
						pTextDrawPool->SetSelectState(false, 0);
					}
					else if(pDialogWindow->GetState())
					{
						pDialogWindow->Show(false);
						if(pNetGame) 
							pNetGame->SendDialogResponse(pDialogWindow->GetCurrentDialogId(), 0, -1, szDialogInputBuffer);
					}
				}
				return;
			}
		}

		if(ImGui::Button(m_bIsExtraShow ? OBFUSCATE("<<") : OBFUSCATE(">>"), ImVec2(m_fButWidth, m_fButHeight)))
			m_bIsExtraShow = !m_bIsExtraShow;

		if(m_bIsExtraShow) 
		{
			ImGui::SameLine(0, 20);

			if(pSettings->Get().TAB == true)
			{
				if(ImGui::Button(OBFUSCATE("TAB"), ImVec2(m_fButWidth, m_fButHeight)))
				{
					if(!pScoreBoard->m_bToggle)
						pScoreBoard->Toggle();

					if(!pPlayerPed->IsInVehicle()) 
						LocalPlayerKeys.bKeys[ePadKeys::KEY_ACTION] = true;
				}
			}

			ImGui::SameLine(0, 20);

			if(pSettings->Get().ALT == true)
			{
				if(ImGui::Button(OBFUSCATE("ALT"), ImVec2(m_fButWidth, m_fButHeight)))
				{
					if(!pPlayerPed->IsInVehicle())
						LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK] = true;
					else LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = true;
				}
			}

			if(pSettings->Get().LMB == true)
			{
				if(!pPlayerPed->IsInVehicle())
				{
					ImGui::SameLine(0, 20);
					if(ImGui::Button(OBFUSCATE("LMB"), ImVec2(m_fButWidth, m_fButHeight)))
						LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = true;
				}
			}

			if(pSettings->Get().F == true)
			{
				ImGui::SameLine(0, 20);
				if(ImGui::Button(OBFUSCATE("F"), ImVec2(m_fButWidth, m_fButHeight)))
					LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = true;
			}

			if(pSettings->Get().H == true)
			{
			
				ImGui::SameLine(0, 20);
				if(ImGui::Button(OBFUSCATE("H"), ImVec2(m_fButWidth, m_fButHeight)))
				{
					LocalPlayerKeys.bKeys[ePadKeys::KEY_CTRL_BACK] = true;
				}
			}
		

			if(pSettings->Get().Y == true)
			{				
				ImGui::SameLine(0, 20);
				if(ImGui::Button(OBFUSCATE("Y"), ImVec2(m_fButWidth, m_fButHeight)))
					LocalPlayerKeys.bKeys[ePadKeys::KEY_YES] = true;
			}

			if(pSettings->Get().N == true)
			{
				ImGui::SameLine(0, 20);
				if(ImGui::Button(OBFUSCATE("N"), ImVec2(m_fButWidth, m_fButHeight)))
					LocalPlayerKeys.bKeys[ePadKeys::KEY_NO] = true;
			}

			if(pSettings->Get().C == true)
			{
				if(!pPlayerPed->IsInVehicle())
				{
					ImGui::SameLine(0, 20);
					if(ImGui::Button(OBFUSCATE("C"), ImVec2(m_fButWidth, m_fButHeight)))
						LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = true;
				}
			}

			if(pSettings->Get().TWO == true)
			{
				if(pPlayerPed->IsInVehicle())
				{
					ImGui::SameLine(0, 20);
					if(ImGui::Button(OBFUSCATE("2"), ImVec2(m_fButWidth, m_fButHeight)))
						LocalPlayerKeys.bKeys[ePadKeys::KEY_SUBMISSION] = true;
				}
			}
		}

		if(!pGButton->m_bPassengerEnable)
		{
			CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
			if(pVehiclePool) 
			{
				uint16_t sNearestVehicleID = pVehiclePool->FindNearestToLocalPlayerPed();
				CVehicle *pVehicle = pVehiclePool->GetAt(sNearestVehicleID);
				if(pVehicle)
				{
					if(pVehicle->GetDistanceFromLocalPlayerPed() < 4.0f) 
					{
						CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
						if(pPlayerPool) 
						{
							CLocalPlayer *pLocalPlayer = pPlayerPool->GetLocalPlayer();
							if(pLocalPlayer)
							{
								if(!pLocalPlayer->IsSpectating() && !pPlayerPed->IsInVehicle())
								{
									ImGui::SameLine(0, 20);
									if(ImGui::Button(OBFUSCATE("G"), ImVec2(m_fButWidth, m_fButHeight)))
									{
										pPlayerPed->EnterVehicle(pVehicle->m_dwGTAId, true);
										pLocalPlayer->SendEnterVehicleNotification(sNearestVehicleID, true);
									}
								}
							}
						}
					}
				}
			}
		}

		ImGui::SetWindowSize(ImVec2(-1, -1));
		ImVec2 size = ImGui::GetWindowSize();
		ImGui::SetWindowPos(ImVec2(m_fPosX, m_fPosY));
		ImGui::End();
			
		ImGui::PopStyleColor(3);
		ImGui::PopStyleVar(2);
	}
}
