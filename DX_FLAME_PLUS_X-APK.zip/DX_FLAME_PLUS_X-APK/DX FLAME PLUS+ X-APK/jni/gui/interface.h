#pragma once

#include "../vendor/imgui/imgui.h"
#include "../game/RW/RenderWare.h"


#define	ID_KEY_ALT 1024
#define	ID_KEY_TAB 1
#define	ID_KEY_C 2
#define	ID_KEY_LCTRL 4
#define	ID_KEY_SPACE 8
#define	ID_KEY_ENTER 16
#define	ID_KEY_LSHIFT 32
#define	ID_KEY_E 64
#define	ID_KEY_RMB 128
#define	ID_KEY_Q 256
#define	ID_KEY_TWO 320
#define	ID_KEY_TWOS 512
#define	ID_KEY_Y 65536
#define	ID_KEY_N 131072
#define	ID_KEY_H 26144


enum typeState
{
    OFF = 0,
    ON
};

class CInterface {

public:
    CInterface();
    ~CInterface();

    void RenderHud() const;
    void RenderMenu();
    void RenderSpeedometer();

    static void SetupKeyboardStyle();

    void ToggleHudState() { m_bRenderHud = !m_bRenderHud; }
    void ToggleMenuState() { m_bRenderMenu = !m_bRenderMenu; }

    void SetWantedLevel(int level) { m_iWantedLevel = level; }

    void SetHudID(int id) { m_iCurrentHudID = id; }
    int GetHudID() const { return m_iCurrentHudID; }
    void SendKeyUsing(int keyId);
    void EngineState(bool b) { bEngine = b; }
    void LightState(bool b) { bLight = b; }
    void LockState(bool b) { bLock = b; }
    void BeltState(bool b) { bBelt = b; }

public :
	uint16_t	key;
private:
    int m_iCurrentHudID;
    int m_iWantedLevel;
	
	int m_iCurrentVolumePlayer;

    bool m_bRenderHud;
    bool m_bRenderMenu;

    RwTexture* logo, *iHeart, *iEat, *iShield, *iWanted;
    RwTexture *iLogo;
    RwTexture *iFist[47]; 

    ImFont* speedFont;
    RwTexture *engineTex0, *engineTex1,
     *lockTex0, *lockTex1, 
     *lightTex0, *lightTex1,
     *beltTex0, *beltTex1,
     *fuelTex,
	 *panelBackground,
     *healthTex; 
     //*arrowLTex[2], 
     //*arrowRTex[2];
    bool bEngine, bLight, bLock, bBelt;
    int iMileage;
};
