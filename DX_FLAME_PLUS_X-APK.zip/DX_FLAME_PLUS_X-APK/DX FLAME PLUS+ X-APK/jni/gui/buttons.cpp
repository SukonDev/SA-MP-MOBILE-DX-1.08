//
// Created by LoonyDev on 09.10.2020.
//

#include "main.h"
#include "../game/game.h"
#include "net/netgame.h"
#include "dialog.h"
#include "GButton.h"
#include "scoreboard.h"
#include "keyboard.h"
#include "buttons.h"
#include "../settings.h"
#include "interface.h"

extern CInterface *pInterface;
extern CKeyBoard *pKeyBoard;
extern CDialogWindow *pDialogWindow;
extern CGame *pGame;
extern CScoreBoard *pScoreBoard;
extern CNetGame *pNetGame;
extern CGUI *pGUI;
extern CGButton *pGButton;
extern CSettings *pSettings;

CButtons::CButtons() {
    btnID = pSettings->Get().iBtnStyle;
    currentBtnID = btnID;

    m_bIsItemShow = false;
    m_bIsShow = true;

    ChangeButtons(pSettings->Get().iBtnStyle);
}

void CButtons::Render() {
    if (pKeyBoard->IsOpen() || pDialogWindow->m_bIsActive || !m_bIsShow) {
        return;
    }

    if (currentBtnID != btnID)
        ChangeButtons(btnID);

    m_fButWidth = 80;
    m_fButHeight = ImGui::CalcTextSize("QWER").x;

    //ImGui::PushStyleColor(ImGuiCol_Button, (ImVec4)ImColor(51,153, 255, 255).Value);
    ImGui::PushStyleColor(ImGuiCol_Button, (ImVec4)ImColor(40,40, 40, 255).Value);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, (ImVec4)ImColor(0.00f, 0.00f, 0.00f, 0.80f).Value);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, (ImVec4)ImColor(0x00, 0x00, 0x00, 0x00).Value);
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, (ImVec4)ImColor(40,40, 40, 255).Value);

    CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
    if (pPlayerPed) {
        ImGuiIO& io = ImGui::GetIO();

        ImGui::GetStyle().ButtonTextAlign = ImVec2(0.5f, 0.5f);
        ImGui::GetStyle().WindowPadding = ImVec2(8, 8);
        ImGui::GetStyle().FrameBorderSize = 2.0f;
        ImGui::GetStyle().FrameRounding = 0.0f;

        ImGui::Begin("Peerapol Unarak", nullptr, ImGuiWindowFlags_NoTitleBar  | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings);

        if (!pScoreBoard->m_bToggle) 
		{
            if (ImGui::Button("Tab", ImVec2(m_fButWidth, m_fButHeight))) // TAB
                pScoreBoard->Toggle();
        }
        else 
		{
            if (ImGui::Button("X", ImVec2(m_fButWidth, m_fButHeight)))
                pScoreBoard->Toggle();

            m_bIsItemShow = false;
        }

        ImGui::SameLine(0, 5);

        if (m_bIsItemShow) 
		{
            if (ImGui::Button("<<", ImVec2(m_fButWidth, m_fButHeight)))
                m_bIsItemShow = !m_bIsItemShow;

            ImGui::SameLine();

            if (ImGui::Button("Alt", ImVec2(m_fButWidth, m_fButHeight)))
                LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK] = true;
                pInterface->SendKeyUsing(1);

            ImGui::SameLine();

            if (ImGui::Button("CTRL", ImVec2(m_fButWidth, m_fButHeight)))
                LocalPlayerKeys.bKeys[ePadKeys::KEY_ACTION] = true;

            ImGui::SameLine();

            if (ImGui::Button("F", ImVec2(m_fButWidth, m_fButHeight)))
                LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = true;

            ImGui::SameLine();
            
            if (ImGui::Button("H", ImVec2(m_fButWidth, m_fButHeight)))
                
                LocalPlayerKeys.bKeys[ePadKeys::KEY_CTRL_BACK] = true;
                pInterface->SendKeyUsing(3);
            ImGui::SameLine();
       
            if (ImGui::Button("Y", ImVec2(m_fButWidth, m_fButHeight)))
                LocalPlayerKeys.bKeys[ePadKeys::KEY_YES] = true;

            ImGui::SameLine();

            if (ImGui::Button("N", ImVec2(m_fButWidth, m_fButHeight)))
                LocalPlayerKeys.bKeys[ePadKeys::KEY_NO] = true;
                pInterface->SendKeyUsing(2);

            ImGui::SameLine();
        }
        else 
		{
            if (ImGui::Button(">>", ImVec2(m_fButWidth, m_fButHeight)))
                m_bIsItemShow = !m_bIsItemShow;

            ImGui::SameLine();

            if (pPlayerPed->IsInVehicle())
            {
                if (ImGui::Button("2", ImVec2(m_fButWidth, m_fButHeight)))
                    LocalPlayerKeys.bKeys[ePadKeys::KEY_SUBMISSION] = true;
            }
            else
            {
                if (ImGui::Button("Alt", ImVec2(m_fButWidth, m_fButHeight)))
                    LocalPlayerKeys.bKeys[ePadKeys::KEY_WALK] = true;
            }

            ImGui::SameLine();
        }

        ImGui::SetWindowSize(ImVec2(-1, -1));
        ImGui::SetWindowPos(ImVec2(2.0f, (io.DisplaySize.y / 3) - (m_fButWidth / 2) + io.DisplaySize.y / 30));

        ImGui::End();
        ImGui::PopStyleColor(3);
    }
}

void CButtons::ChangeButtons(int _btnID)
{
   /* btnID = _btnID;

    sprintf(btn_tab_tex,    "btn_tab_%d",   btnID);
    sprintf(btn_h_tex,      "btn_h_%d",     btnID);
    sprintf(btn_f_tex,      "btn_f_%d",     btnID);
    sprintf(btn_y_tex,      "btn_y_%d",     btnID);
    sprintf(btn_n_tex,      "btn_n_%d",     btnID);
    sprintf(btn_ctrl_tex,   "btn_ctrl_%d",  btnID);
    sprintf(btn_two_tex,    "btn_two_%d",   btnID);
    sprintf(btn_sl_tex,     "btn_sl_%d",    btnID);
    sprintf(btn_sr_tex,     "btn_sr_%d",    btnID);
    sprintf(btn_alt_tex,    "btn_alt_%d",   btnID);

    btn_tab  = (RwTexture*)LoadTextureFromDB("gtasa", btn_tab_tex);
    btn_h    = (RwTexture*)LoadTextureFromDB("gtasa", btn_h_tex);
    btn_f    = (RwTexture*)LoadTextureFromDB("gtasa", btn_f_tex);
    btn_y    = (RwTexture*)LoadTextureFromDB("gtasa", btn_y_tex);
    btn_n    = (RwTexture*)LoadTextureFromDB("gtasa", btn_n_tex);
    btn_ctrl = (RwTexture*)LoadTextureFromDB("gtasa", btn_ctrl_tex);
    btn_two  = (RwTexture*)LoadTextureFromDB("gtasa", btn_two_tex);
    btn_sl   = (RwTexture*)LoadTextureFromDB("gtasa", btn_sl_tex);
    btn_sr   = (RwTexture*)LoadTextureFromDB("gtasa", btn_sr_tex);
    btn_alt  = (RwTexture*)LoadTextureFromDB("gtasa", btn_alt_tex); */

    currentBtnID = btnID;
}

void CButtons::ToggleState()
{
    m_bIsShow = !m_bIsShow;
}
