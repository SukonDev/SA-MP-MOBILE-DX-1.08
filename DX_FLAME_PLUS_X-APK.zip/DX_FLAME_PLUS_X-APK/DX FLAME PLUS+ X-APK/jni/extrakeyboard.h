#pragma once

#include "game/RW/RenderWare.h"

#include "gui/gui.h"

class CExtraKeyBoard
{
	friend class CGUI;
public:
	CExtraKeyBoard();
	~CExtraKeyBoard();

	//void Render();
	void Clear();
	//void Show(bool bShow);

	RwTexture* b_backpack = nullptr;
	RwTexture* b_job = nullptr;
	RwTexture* b_car = nullptr;
	RwTexture* b_phone = nullptr;
	RwTexture* b_dance = nullptr;
	RwTexture* b_talk = nullptr;
	
private:
	bool		m_boardplayer;
	bool 		m_passengerUseTexture;
	bool 		m_bDriveByMode;
	RwTexture 	*m_passengerButtonTexture[2];
	uint32_t	m_dwLastTickPassengerHover;
	
public:
	void SetPosition(float posX, float posY);
	void SetButtonSize(float sizeX, float sizeY);

protected:
	void Render();

public:
	void Show(bool bShow) { m_bIsActive = bShow; }
	
private:
	bool 		m_bIsActive;
	bool 		m_bIsExtraShow;

	float 		m_fPosX;
	float 		m_fPosY;
	float 		m_fSizeX;
	float 		m_fSizeY;
};
