#include "main.h"
#include "gui/gui.h"
#include "game/game.h"
#include "net/netgame.h"
#include "settings.h"
#include "dialog.h"
#include "spawnscreen.h"
#include "menucustom.h"
#include "scoreboard.h"
#include "settings.h"
#include "gui/gamescreen.h"
#include "gui/interface.h"

extern CGameScreen *pGameScreen;
extern CInterface *pInterface;
extern CGUI *pGUI;
extern CGame *pGame;
extern CNetGame *pNetGame;
extern CSettings *pSettings;
extern CScoreBoard *pScoreBoard;
extern CDialogWindow *pDialogWindow;
extern CSpawnScreen *pSpawnScreen;
extern CSettings *pSettings;

CMenuCustom::CMenuCustom() 
{
	m_bIsActive = false;
	m_bIsExtraShow = false;
	
	Log("Extrakeyboard initialized.");
}

CMenuCustom::~CMenuCustom() 
{ 
	m_bIsActive = false;
	m_bIsExtraShow = false;
	//page = 0;
	if(m_passengerUseTexture)
	{
		for(int i = 0; i < 2; i++)
			m_passengerButtonTexture[i] = nullptr;

		m_dwLastTickPassengerHover = GetTickCount();
	}
}

void CMenuCustom::show(bool bShow) 
{
	m_bIsActive = bShow;
}

void CMenuCustom::Render() 
{
	if(!m_bIsActive)
		return;
    
	bool bDontExpand = false;
//    page  = 0;
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	pGUI->SetupDefaultStyle();
     
    ImGuiIO& io = ImGui::GetIO();
    ImGui::Begin("#menu", nullptr,
                 ImGuiWindowFlags_NoTitleBar
                 | ImGuiWindowFlags_NoResize
                 | ImGuiWindowFlags_NoSavedSettings
                 | ImGuiWindowFlags_NoScrollbar
                 | ImGuiWindowFlags_NoMove
    );

    ImGui::GetBackgroundDrawList()->AddRectFilled(
            ImVec2(ImGui::GetWindowPos().x, ImGui::GetWindowPos().y),
            ImVec2(ImGui::GetWindowPos().x + ImGui::GetWindowSize().x, ImGui::GetWindowPos().y + ImGui::GetFontSize() * 2),
            0xFF000000
    );
    
    ImGui::Text("เมนูการปรับแต่ง");
    ImGui::Separator();

    ImGui::BeginChild("#__menu", ImVec2(-1, ImGui::GetWindowSize().y - ImGui::GetFontSize() * 4.7f), false);

    ImGui::Separator();
    if(page == 0){
    //ImGui::Checkbox("แสดงเวลาหน้าแชท", &pGUI->timestamp);
    ImGui::Checkbox("พื้นหลัง 3D Text", &pGUI->bLabelBackground);
    //ImGui::Checkbox("แชทแบบเฟด", &pSettings->Get().iChatShadow);
    ImGui::Checkbox("ตัวนับ FPS", &pSettings->Get().iFPSCounter);
	//ImGui::Checkbox("พื้นหลังปุ่ม", &pSettings->Get().BTBack);
	//ImGui::Checkbox("ขอบปุ่มกด", &pSettings->Get().BTBord);
	//ImGui::Checkbox("ปรับปุ่มให้โค้งมน", &pSettings->Get().BTRadius);
	ImGui::Text("เพิ่ม/ลบ ปุ่มกด");
	ImGui::Checkbox("ALT", &pSettings->Get().ALT);
	ImGui::Checkbox("TAB", &pSettings->Get().TAB);
	ImGui::Checkbox("F", &pSettings->Get().F);
	ImGui::Checkbox("Y", &pSettings->Get().Y);
	ImGui::Checkbox("N", &pSettings->Get().N);
	ImGui::Checkbox("H", &pSettings->Get().H);
	ImGui::Checkbox("C", &pSettings->Get().C);
	ImGui::Checkbox("2", &pSettings->Get().TWO);
	
	/*ImGui::Checkbox("ENTER", &pSettings->Get().ENTER);
	ImGui::Checkbox("SPACE", &pSettings->Get().SPACE);
	ImGui::Checkbox("RBM", &pSettings->Get().RBM);
	ImGui::Checkbox("CTRL", &pSettings->Get().CTRL);
	ImGui::Checkbox("NUM8", &pSettings->Get().NUM8);
	ImGui::Checkbox("NUM2", &pSettings->Get().NUM2);
	ImGui::Checkbox("NUM4", &pSettings->Get().NUM4);
	ImGui::Checkbox("NUM6", &pSettings->Get().NUM6);*/

    static float fTempDist = pSettings->Get().fDrawPedDist;
    pSettings->Get().fDrawPedDist = fTempDist;
    ImGui::Separator();
    }
    if (ImGui::Button("ปิดหน้าต่าง", ImVec2(200, 80)))
        show(false);
    ImGui::EndChild();


    ImGui::SetWindowSize(ImVec2(pGUI->ScaleY(1500), pGUI->ScaleY(700)));
    ImGui::SetWindowPos(ImVec2(((io.DisplaySize.x - ImGui::GetWindowSize().x) / 2), ((io.DisplaySize.y - ImGui::GetWindowSize().y) / 2)));

    ImGui::End();
	return;
}
