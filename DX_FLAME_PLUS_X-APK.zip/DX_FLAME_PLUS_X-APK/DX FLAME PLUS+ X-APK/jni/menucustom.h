#pragma once

class CMenuCustom
{
public:
	CMenuCustom();
	~CMenuCustom();

	void Render();
	void Clear();
	void show(bool bShow);
	int page;
	
private:
	bool 		m_bIsActive;
	bool 		m_bIsExtraShow;
	bool 		m_passengerUseTexture;
	RwTexture 	*m_passengerButtonTexture[2];
	uint32_t	m_dwLastTickPassengerHover;
};
