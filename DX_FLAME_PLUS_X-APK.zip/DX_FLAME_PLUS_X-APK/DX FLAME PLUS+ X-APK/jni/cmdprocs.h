#pragma once

void SetupCommands();