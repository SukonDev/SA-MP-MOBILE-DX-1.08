#include "../util/util.h"
#include <cstdio>
#include <iostream>
#include <iomanip>
#include <sstream>
#include "../gui/buttons.h"
#include "../gui/interface.h"
#include "../gui/gamescreen.h"
#include "game/common.h"
#include "keyboard.h"

#include "voice/Playback.h"
#include "voice/Record.h"

extern CGUI *pGUI;
extern CChatWindow *pChatWindow;
extern CGameScreen* pGameScreen;
extern CKeyBoard *pKeyBoard;

uintptr_t FindLibrary(const char* library)
{
    char filename[0xFF] = {0},
    buffer[2048] = {0};
    FILE *fp = 0;
    uintptr_t address = 0;

    sprintf( filename, "/proc/%d/maps", getpid() );

    fp = fopen( filename, "rt" );
    if(fp == 0)
    {
        Log("ERROR: can't open file %s", filename);
        goto done;
    }

    while(fgets(buffer, sizeof(buffer), fp))
    {
        if( strstr( buffer, library ) )
        {
            address = (uintptr_t)strtoul( buffer, 0, 16 );
            break;
        }
    }

    done:

    if(fp)
      fclose(fp);

    return address;
}

void cp1251_to_utf8(char *out, const char *in, unsigned int len)
{
    static const int table[128] = 
    {    
        // 80
        0,     0,     0,   0,     0,   0,   0,   0,
        0,   0,   0,     0,   0,     0,     0,     0,
        // 90
        0,     0,   0,   0,   0,   0,   0,   0,
        0,      0,   0,     0,   0,     0,     0,     0,                
        // A0
        0x80b8e0,0x81b8e0,0x82b8e0,0x83b8e0,0x84b8e0,0x85b8e0,0x86b8e0,0x87b8e0,
        0x88b8e0,0x89b8e0,0x8ab8e0,0x8bb8e0,0x8cb8e0,0x8db8e0,0x8eb8e0,0x8fb8e0,
        // B0
        0x90b8e0,0x91b8e0,0x92b8e0,0x93b8e0,0x94b8e0,0x95b8e0,0x96b8e0,0x97b8e0,
        0x98b8e0,0x99b8e0,0x9ab8e0,0x9bb8e0,0x9cb8e0,0x9db8e0,0x9eb8e0,0x9fb8e0,
        // C0
        0xa0b8e0,0xa1b8e0,0xa2b8e0,0xa3b8e0,0xa4b8e0,0xa5b8e0,0xa6b8e0,0xa7b8e0,
        0xa8b8e0,0xa9b8e0,0xaab8e0,0xabb8e0,0xacb8e0,0xadb8e0,0xaeb8e0,0xafb8e0,
        // D0
        0xb0b8e0,0xb1b8e0,0xb2b8e0,0xb3b8e0,0xb4b8e0,0xb5b8e0,0xb6b8e0,0xb7b8e0,
        0xb8b8e0,0xb9b8e0,0xbab8e0,0       ,0       ,0       ,0       ,0xbfb8e0,
        // E0
        0x80b9e0,0x81b9e0,0x82b9e0,0x83b9e0,0x84b9e0,0x85b9e0,0x86b9e0,0x87b9e0,
        0x88b9e0,0x89b9e0,0x8ab9e0,0x8bb9e0,0x8cb9e0,0x8db9e0,0x8eb9e0,0x8fb9e0,
        // F0
        0x90b9e0,0x91b9e0,0x92b9e0,0x93b9e0,0x94b9e0,0x95b9e0,0x96b9e0,0x97b9e0,
        0x98b9e0,0x99b9e0,0x9ab9e0,0x9bb9e0
    };

    int count = 0;

    while (*in)
    {
        if(len && (count >= len)) break;

        // if (*in > 0x7e)
        if (*in > 0x80)
        {
            int v = table[(int)(0x7f & *in++)];
            if (!v)
                continue;

            *out++ = (char)v;
            *out++ = (char)(v >> 8);
            *out++ = (char)(v >> 16);
            /*char v = (int)&in++[count];
            if (((0xa1 <= v) && (v <= 0xda))
            || ((0xdf <= v) && (v <= 0xfb))) {
                char utf8Char = 0x0e00 + v - 0xa0;
                char utf8Byte1 = (char)(0xe0 | (utf8Char >> 12));
                *out++ = utf8Byte1;
                char utf8Byte2 = (char)(0x80 | ((utf8Char >> 6) & 0x3f));
                *out++ = utf8Byte2;
                char utf8Byte3 = (char)(0x80 | (utf8Char & 0x3f));
                *out++ = utf8Byte3;
            }*/

        }
        else // ASCII
            *out++ = *in++;

        count++;
    }

    *out = 0;
}

/*void cp1251_to_utf8(char *out, const char *in, unsigned int len)
{
    static const int table[128] =
    {
        // 80
        0,     0,     0,   0,     0,   0,   0,   0,
        0,   0,   0,     0,   0,     0,     0,     0,
        // 90
        0,     0,   0,   0,   0,   0,   0,   0,
        0,      0,   0,     0,   0,     0,     0,     0,                
        // A0
        0x80b8e0,0x81b8e0,0x82b8e0,0x83b8e0,0x84b8e0,0x85b8e0,0x86b8e0,0x87b8e0,
        0x88b8e0,0x89b8e0,0x8ab8e0,0x8bb8e0,0x8cb8e0,0x8db8e0,0x8eb8e0,0x8fb8e0,
        // B0
        0x90b8e0,0x91b8e0,0x92b8e0,0x93b8e0,0x94b8e0,0x95b8e0,0x96b8e0,0x97b8e0,
        0x98b8e0,0x99b8e0,0x9ab8e0,0x9bb8e0,0x9cb8e0,0x9db8e0,0x9eb8e0,0x9fb8e0,
        // C0
        0xa0b8e0,0xa1b8e0,0xa2b8e0,0xa3b8e0,0xa4b8e0,0xa5b8e0,0xa6b8e0,0xa7b8e0,
        0xa8b8e0,0xa9b8e0,0xaab8e0,0xabb8e0,0xacb8e0,0xadb8e0,0xaeb8e0,0xafb8e0,
        // D0
        0xb0b8e0,0xb1b8e0,0xb2b8e0,0xb3b8e0,0xb4b8e0,0xb5b8e0,0xb6b8e0,0xb7b8e0,
        0xb8b8e0,0xb9b8e0,0xbab8e0,0       ,0       ,0       ,0       ,0xbfb8e0,
        // E0
        0x80b9e0,0x81b9e0,0x82b9e0,0x83b9e0,0x84b9e0,0x85b9e0,0x86b9e0,0x87b9e0,
        0x88b9e0,0x89b9e0,0x8ab9e0,0x8bb9e0,0x8cb9e0,0x8db9e0,0x8eb9e0,0x8fb9e0,
        // F0
        0x90b9e0,0x91b9e0,0x92b9e0,0x93b9e0,0x94b9e0,0x95b9e0,0x96b9e0,0x97b9e0,
        0x98b9e0,0x99b9e0,0x9ab9e0,0x9bb9e0,//128	
    };

    int count = 0;

    while (*in)
    {
        if(len && (count >= len)) break;

        if (*in & 0x80)
        {
            register int v = table[(int)(0x7f & *in++)];
            if (!v)
                continue;
            *out++ = (char)v;
            *out++ = (char)(v >> 8);
            if (v >>= 16)
                *out++ = (char)v;
        }
        else // ASCII
            *out++ = *in++;

        count++;
    }

    *out = 0;
}*/

void Log(const char *fmt, ...)
{
    char buffer[0xFF];
    static FILE* flLog = nullptr;

    memset(buffer, 0, sizeof(buffer));

    va_list arg;
            va_start(arg, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, arg);
            va_end(arg);

    if(flLog == nullptr && g_pszStorage != nullptr)
    {
        sprintf(buffer, "%sSAMP/samplog.txt", g_pszStorage);

        flLog = fopen(buffer, "w");
    }

    __android_log_write(ANDROID_LOG_INFO, "AXL", buffer);

    if(pDebug) pDebug->AddMessage(buffer);

    if(flLog == nullptr)
        return;

    fprintf(flLog, "%s\n", buffer);
    fflush(flLog);
}

void LogVoice(const char *fmt, ...)
{   
    char buffer[0xFF];
    static FILE* flLog = nullptr;

    memset(buffer, 0, sizeof(buffer));

    va_list arg;
            va_start(arg, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, arg);
            va_end(arg);

    if(flLog == nullptr && g_pszStorage != nullptr)
    {
        sprintf(buffer, "%sSAMP/sampvoice.txt", g_pszStorage);

        flLog = fopen(buffer, "w");
    }

    __android_log_write(ANDROID_LOG_INFO, "AXL", buffer);

    if(pDebug) pDebug->AddMessage(buffer);

    if(flLog == nullptr)
        return;

    fprintf(flLog, "%s\n", buffer);
    fflush(flLog);
}

int clampEx(int source, int min, int max)
{
    if(source < min) return min;
    if(source > max) return max;
    return source;
}

float clampEx(float source, float min, float max)
{
    if(source < min) return min;
    if(source > max) return max;
    return source;
}

void FLog(const char *fmt)
{
    char buffer[0xFF];
    static FILE* flLog = nullptr;
    char date[80];

    if(flLog == nullptr && g_pszStorage != nullptr)
    {
        sprintf(buffer, "%sSAMP/scripts/lua.log", g_pszStorage);

        flLog = fopen(buffer, "w");
    }

    time_t rt;
    struct tm* ti;
    time(&rt);
    ti = localtime(&rt);

    sprintf(date, "%02i:%02i:%02i", ti->tm_hour, ti->tm_min, ti->tm_sec);
    sprintf(buffer, "%s | %s", date, fmt);

    __android_log_write(ANDROID_LOG_INFO, "AXL", buffer);

    if(pDebug) pDebug->AddMessage(buffer);

    if(flLog == nullptr)
        return;


    fprintf(flLog, "%s\n", buffer);
    fflush(flLog);
}

uint32_t GetTickCount()
{
	struct timeval tv;
	gettimeofday(&tv, nullptr);
	return (tv.tv_sec*1000+tv.tv_usec/1000);
}

#include "../settings.h"
extern CSettings* pSettings;
bool SaveMenuSettings()
{
    char buff[0x7F];
    sprintf(buff, "%sSAMP/settings.ini", g_pszStorage);

    CSimpleIniA ini;
    ini.SetUnicode();
    ini.LoadFile(buff);
    SI_Error rc;

    rc = ini.SetBoolValue("client", "timestamp", pGUI->timestamp);
    rc = ini.SetBoolValue("client", "radar", pSettings->Get().szRadar);
    rc = ini.SetBoolValue("client", "ChatShadow", pSettings->Get().iChatShadow);
    rc = ini.SetBoolValue("client", "textbg", pGUI->m_bRenderTextBg);
    rc = ini.SetBoolValue("client", "chatbg", pGUI->m_bRenderCBbg);
    rc = ini.SetDoubleValue("client", "btn_style", pGameScreen->GetButtons()->btnID);
    rc = ini.SetDoubleValue("client", "hud_style", pGameScreen->GetInterface()->GetHudID());
    rc = ini.SetBoolValue("client", "label_background", pGUI->bLabelBackground);
    rc = ini.SetBoolValue("client", "noFX", pSettings->Get().bnoFX);
    rc = ini.SetDoubleValue("client", "DrawDistPed", pSettings->Get().fDrawPedDist);
	
    rc = ini.SetBoolValue("gui", "VoiceChatEnable", pSettings->Get().bVoiceChatEnable);
	
    rc = ini.SetBoolValue("gui", "androidkeyboard", pSettings->Get().iAndroidKeyboard);
    rc = ini.SetBoolValue("gui", "cutout", pSettings->Get().iCutout);
    rc = ini.SetBoolValue("gui", "fpscounter", pSettings->Get().iFPSCounter);
	
	if(!pSettings->Get().iAndroidKeyboard) pKeyBoard->EnableOldKeyboard();
	else pKeyBoard->EnableNewKeyboard();
	
	/*if(!pSettings->Get().bVoiceChatEnable)
	{
		Playback::SetSoundEnable(false);
		Record::SetMicroEnable(false);
	}
	else
	{*/
		Playback::SetSoundEnable(true);
		Record::SetMicroEnable(true);
	//}
	
    rc = ini.SaveFile(buff);

    return (rc >= 0);
}

std::string formatInt (unsigned int i) {
    std::string result = to_string(i);
    int length = 0;

    if ((length = result.length()) > 3)
    {
        for (int idx = length, l = 0; --idx >= 0; l++)
        {
            if ((l > 0) && (l % 3 == 0)) result.insert(idx + 1, ","); // --> strins(value, ",", idx + 1); -> Pawn
        }
    }

    return result;
}

const char *GetWeaponTextureName(int iWeaponID)
{
    switch (iWeaponID) {
        case WEAPON_BRASSKNUCKLE:   return "fh1_kastet";
        case WEAPON_GOLFCLUB:       return "fh1_golf";
        case WEAPON_NITESTICK:      return "fh1_nitestick";
        case WEAPON_KNIFE:          return "fh1_knife";
        case WEAPON_BAT:            return "fh1_bat";
        case WEAPON_SHOVEL:         return "fh1_shovel";
        case WEAPON_POOLSTICK:      return "fh1_poolstick";
        case WEAPON_KATANA:         return "fh1_katana";
        case WEAPON_CHAINSAW:       return "fh1_chainsaw";
        case WEAPON_DILDO:          return "fh1_dildo";
        case WEAPON_DILDO2:         return "fh1_dildo2";
        case WEAPON_VIBRATOR:       return "fh1_vibrator";
        case WEAPON_VIBRATOR2:      return "fh1_vibrator2";
        case WEAPON_FLOWER:         return "fh1_flower";
        case WEAPON_CANE:           return "fh1_cane";
        case WEAPON_GRENADE:        return "fh1_grenade";
        case WEAPON_TEARGAS:        return "fh1_teargas";
        case WEAPON_MOLTOV:         return "fh1_molotov";
        case WEAPON_COLT45:         return "fh1_colt";
        case WEAPON_SILENCED:       return "fh1_silenced";
        case WEAPON_DEAGLE:         return "fh1_desert_eagle";
        case WEAPON_SHOTGUN:        return "fh1_shotgun";
        case WEAPON_SAWEDOFF:       return "fh1_sawedoff";
        case WEAPON_SHOTGSPA:       return "fh1_";
        case WEAPON_UZI:            return "fh1_uzi";
        case WEAPON_MP5:            return "fh1_mp5";
        case WEAPON_AK47:           return "fh1_ak47";
        case WEAPON_M4:             return "fh1_m4";
        case WEAPON_TEC9:           return "fh1_tec9";
        case WEAPON_RIFLE:          return "fh1_rifle";
        case WEAPON_SNIPER:         return "fh1_sniper";
        case WEAPON_ROCKETLAUNCHER: return "fh1_rpg";
        case WEAPON_HEATSEEKER:     return "fh1_heatseeker";
        case WEAPON_FLAMETHROWER:   return "fh1_fist"; // --> TODO -> Create icon --> --> --> --> -->
        case WEAPON_MINIGUN:        return "fh1_minigun";
        case WEAPON_SATCHEL:        return "fh1_bomb";
        case WEAPON_BOMB:           return "fh1_bomb";
        case WEAPON_SPRAYCAN:       return "fh1_spraycan";
        case WEAPON_FIREEXTINGUISHER: return "fh1_fire";
        case WEAPON_CAMERA:         return "fh1_camera";
        case WEAPON_PARACHUTE:      return "fh1_fist"; // --> TODO -> Create icon --> --> --> --> -->
    }

    return "fh1_fist";
}

